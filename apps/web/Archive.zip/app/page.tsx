"use client";

import React, { useEffect, useMemo, useState } from "react";
import dynamic from "next/dynamic";
import { useConnection, useWallet } from "@solana/wallet-adapter-react";
import {
  PublicKey,
  Transaction,
  TransactionInstruction,
  Ed25519Program,
  SystemProgram,
} from "@solana/web3.js";

import UserDashboard from "../components/UserDashboard";

const WalletButton = dynamic(() => import("../components/WalletButton"), { ssr: false });

// ✅ IMPORTANT: update to your latest deployed program id
const PROGRAM_ID = new PublicKey("BtJDtqG3Zy25gZC43H7q1TXTqjoeSh4JBHVYiWzwd2cb");
const IX_SYSVAR = new PublicKey("Sysvar1nstructions1111111111111111111111111");
const CLUSTER = "devnet";

// ---------- byte helpers (browser-safe, no Buffer) ----------
function randBytes(n: number) {
  const b = new Uint8Array(n);
  crypto.getRandomValues(b);
  return b;
}

function bytesToHex(bytes: Uint8Array) {
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function b64ToBytes(b64: string) {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

function bytesToB64(bytes: Uint8Array) {
  let bin = "";
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin);
}

function writeI64LE(view: DataView, offset: number, value: bigint) {
  view.setBigInt64(offset, value, true);
}

// CPv1 payload = "CPv1" | user(32) | day(i64 LE) | sessionHash(32) | nonce(16) | expiresAt(i64 LE)
function buildPayloadBytes(
  userPk: PublicKey,
  day: bigint,
  sessionHash32: Uint8Array,
  nonce16: Uint8Array,
  expiresAt: bigint
) {
  const out = new Uint8Array(4 + 32 + 8 + 32 + 16 + 8);
  const view = new DataView(out.buffer);

  let o = 0;
  out.set(new TextEncoder().encode("CPv1"), o);
  o += 4;

  out.set(userPk.toBytes(), o);
  o += 32;

  writeI64LE(view, o, day);
  o += 8;

  out.set(sessionHash32, o);
  o += 32;

  out.set(nonce16, o);
  o += 16;

  writeI64LE(view, o, expiresAt);
  o += 8;

  return out;
}

// Anchor discriminator = sha256("global:<name>")[0..8]
async function discriminator(name: string) {
  const msg = new TextEncoder().encode(`global:${name}`);
  const hash = await crypto.subtle.digest("SHA-256", msg);
  return new Uint8Array(hash).slice(0, 8);
}

async function buildInitUserIx(user: PublicKey, userStatePda: PublicKey) {
  const disc = await discriminator("init_user"); // no args
  return new TransactionInstruction({
    programId: PROGRAM_ID,
    keys: [
      { pubkey: user, isSigner: true, isWritable: true },
      { pubkey: userStatePda, isSigner: false, isWritable: true },
      { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
    ],
    data: disc,
  });
}

function friendlyTxError(e: any) {
  const msg = String(e?.message ?? e);
  const logs: string[] = e?.logs ?? e?.transactionLogs ?? [];
  const haystack = [msg, ...logs].join("\n");

  if (haystack.includes("AlreadyClaimedToday") || haystack.includes("6001")) {
    return "✅ You already claimed today. Come back tomorrow for streak +1.";
  }
  if (haystack.toLowerCase().includes("blockhash not found")) {
    return "Network hiccup (blockhash expired). Try again.";
  }
  return msg;
}

function explorerTx(sig: string) {
  return `https://explorer.solana.com/tx/${sig}?cluster=${CLUSTER}`;
}

type FeedEvent = {
  t: number;
  msg: string;
  sig?: string;
};

function shortSig(sig: string) {
  return sig.length > 10 ? `${sig.slice(0, 4)}…${sig.slice(-4)}` : sig;
}

export default function Home() {
  const wallet = useWallet();
  const { connection } = useConnection();

  const [receipt, setReceipt] = useState<any>(null);
  const [status, setStatus] = useState<string>("");
  const [error, setError] = useState<string>("");

  // Dashboard refresh trigger (still useful if you want manual bump)
  const [dashboardRefreshNonce, setDashboardRefreshNonce] = useState(0);

  // Live activity feed
  const [feed, setFeed] = useState<FeedEvent[]>([]);

  function pushEvent(msg: string, sig?: string) {
    setFeed((prev) => [{ t: Date.now(), msg, sig }, ...prev].slice(0, 12));
  }

  // Live program logs (wow factor)
  useEffect(() => {
    const subIdPromise = connection.onLogs(
      PROGRAM_ID,
      (logInfo) => {
        pushEvent("Program logs emitted", logInfo.signature);
      },
      "confirmed"
    );

    return () => {
      Promise.resolve(subIdPromise).then((subId: any) => {
        if (typeof subId === "number") connection.removeOnLogsListener(subId);
      });
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [connection]);

  // If you proxied via Next API route, switch to fetch("/api/oracle-sign")
  const oracleUrl = useMemo(() => "http://127.0.0.1:8787", []);

  // ✅ isDev selects between claim_brush (streak) and claim_brush_dev (unlimited testing)
  async function claimOnChain(isDev = false) {
    setError("");
    setStatus("");
    setReceipt(null);

    if (!wallet.publicKey || !wallet.signTransaction) {
      setError("Connect Phantom first.");
      return;
    }

    // --- 1) Build session request ---
    const now = Math.floor(Date.now() / 1000);
    const dayNum = Math.floor(now / 86400);
    const expiresAt = now + 120;

    const sessionHash = randBytes(32);
    const nonce = randBytes(16);

    const reqBody = {
      user: wallet.publicKey.toBase58(),
      day: dayNum,
      sessionHash: bytesToHex(sessionHash),
      nonce: bytesToHex(nonce),
      expiresAt,
      // optional: tell your oracle you want dev mode (if you want)
      // mode: isDev ? "dev" : "prod",
    };

    // --- 2) Ask oracle to sign ---
    setStatus("Requesting oracle signature...");
    pushEvent("Requesting oracle signature…");
    let json: any;
    try {
      const resp = await fetch(`${oracleUrl}/oracle/sign`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(reqBody),
      });
      json = await resp.json();
      if (!resp.ok) {
        setError(json?.error ?? "Oracle request failed");
        pushEvent("Oracle request failed");
        return;
      }
    } catch (e: any) {
      setError(`Oracle unreachable: ${String(e?.message ?? e)}`);
      pushEvent("Oracle unreachable");
      return;
    }

    const oraclePubkey = new PublicKey(json.oraclePubkey);
    const sig = b64ToBytes(json.sigB64); // 64 bytes
    const payloadFromOracle = b64ToBytes(json.payloadB64);

    // --- 3) Rebuild payload locally and ensure it matches oracle ---
    const payloadLocal = buildPayloadBytes(
      wallet.publicKey,
      BigInt(dayNum),
      sessionHash,
      nonce,
      BigInt(expiresAt)
    );

    if (bytesToB64(payloadLocal) !== bytesToB64(payloadFromOracle)) {
      setError("Payload mismatch between client and oracle (serialization bug).");
      pushEvent("Payload mismatch (client vs oracle)");
      return;
    }

    setReceipt({ request: reqBody, response: json });
    pushEvent("Oracle receipt verified locally ✅");

    // --- 4) Derive PDAs ---
    const enc = new TextEncoder();

    const [userStatePda] = PublicKey.findProgramAddressSync(
      [enc.encode("user"), wallet.publicKey.toBytes()],
      PROGRAM_ID
    );

    const [claimPda] = PublicKey.findProgramAddressSync(
      [enc.encode("claim"), wallet.publicKey.toBytes(), nonce],
      PROGRAM_ID
    );

    // Check if user_state exists; if not, add init_user ix
    const userStateInfo = await connection.getAccountInfo(userStatePda);
    const needInitUser = !userStateInfo;
    pushEvent(needInitUser ? "UserState missing → will init_user" : "UserState exists");

    // --- 5) Build ed25519 verify instruction (must be BEFORE claim) ---
    const edIx = Ed25519Program.createInstructionWithPublicKey({
      publicKey: oraclePubkey.toBytes(),
      message: payloadLocal,
      signature: sig,
    });

    // --- 6) Build program instruction data for claim_brush / claim_brush_dev ---
    // Layout: disc[8] | day(i64 LE) | session_hash[32] | nonce[16] | expires_at(i64 LE) | sig[64]
    const disc = await discriminator(isDev ? "claim_brush_dev" : "claim_brush");

    const data = new Uint8Array(8 + 8 + 32 + 16 + 8 + 64);
    const view = new DataView(data.buffer);

    let off = 0;
    data.set(disc, off);
    off += 8;

    writeI64LE(view, off, BigInt(dayNum));
    off += 8;

    data.set(sessionHash, off);
    off += 32;

    data.set(nonce, off);
    off += 16;

    writeI64LE(view, off, BigInt(expiresAt));
    off += 8;

    data.set(sig, off);
    off += 64;

    const claimIx = new TransactionInstruction({
      programId: PROGRAM_ID,
      keys: [
        { pubkey: wallet.publicKey, isSigner: true, isWritable: true },
        { pubkey: userStatePda, isSigner: false, isWritable: true },
        { pubkey: claimPda, isSigner: false, isWritable: true },
        { pubkey: IX_SYSVAR, isSigner: false, isWritable: false },
        { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
      ],
      data,
    });

    // --- 7) Build tx (init_user if needed), then ed25519 verify, then claim ---
    setStatus(needInitUser ? "Initializing user (first time)..." : "Building transaction...");
    pushEvent("Building transaction…");

    const tx = new Transaction();
    if (needInitUser) {
      const initIx = await buildInitUserIx(wallet.publicKey, userStatePda);
      tx.add(initIx);
    }

    tx.add(edIx, claimIx);
    tx.feePayer = wallet.publicKey;

    const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash("finalized");
    tx.recentBlockhash = blockhash;

    // --- 8) Sign, send, confirm ---
    setStatus("Signing with Phantom...");
    pushEvent("Signing with Phantom…");
    let signed: Transaction;
    try {
      signed = await wallet.signTransaction(tx);
    } catch (e: any) {
      setError(`Signing cancelled: ${String(e?.message ?? e)}`);
      pushEvent("Signing cancelled");
      return;
    }

    setStatus("Sending transaction...");
    pushEvent("Sending transaction…");
    let sigTx: string;
    try {
      sigTx = await connection.sendRawTransaction(signed.serialize(), { skipPreflight: false });
    } catch (e: any) {
      setError(friendlyTxError(e));
      pushEvent("Send failed");
      return;
    }

    setStatus(`Submitted: ${sigTx} (confirming...)`);
    pushEvent("Submitted", sigTx);

    try {
      await connection.confirmTransaction(
        { signature: sigTx, blockhash, lastValidBlockHeight },
        "confirmed"
      );
    } catch (e: any) {
      setError(`Confirm failed: ${String(e?.message ?? e)}`);
      pushEvent("Confirm failed", sigTx);
      return;
    }

    setStatus(`Confirmed ✅ ${sigTx}`);
    pushEvent("Confirmed ✅", sigTx);

    setDashboardRefreshNonce((n) => n + 1);
  }

  return (
    <main style={{ padding: 24, fontFamily: "ui-sans-serif, system-ui" }}>
      <h1 style={{ fontSize: 28, fontWeight: 700 }}>CavityProof</h1>
      <p style={{ marginTop: 8, opacity: 0.8 }}>
        Phase 4: Oracle-enforced claim (ed25519 verify + nonce replay protection)
      </p>

      <div style={{ marginTop: 16 }}>
        <WalletButton />
      </div>

      <div style={{ marginTop: 16 }}>
        <button
          onClick={() => claimOnChain(false)}
          style={{
            padding: "10px 14px",
            borderRadius: 10,
            border: "1px solid #ccc",
            cursor: "pointer",
          }}
        >
          Claim on-chain (streak)
        </button>

        <button
          onClick={() => claimOnChain(true)}
          style={{
            marginLeft: 10,
            padding: "10px 14px",
            borderRadius: 10,
            border: "1px solid #ccc",
            cursor: "pointer",
          }}
        >
          DEV Claim (unlimited)
        </button>
      </div>

      {status && <pre style={{ marginTop: 16 }}>{status}</pre>}
      {error && <pre style={{ marginTop: 16, color: "crimson" }}>{error}</pre>}

      {/* ✅ Live Activity feed */}
      <div style={{ marginTop: 16, border: "1px solid #333", borderRadius: 14, padding: 12 }}>
        <div style={{ fontWeight: 600, marginBottom: 8 }}>Live Activity</div>
        {feed.length === 0 ? (
          <div style={{ opacity: 0.7 }}>No events yet.</div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {feed.map((e) => (
              <div key={e.t} style={{ fontFamily: "monospace", fontSize: 12, opacity: 0.9 }}>
                {new Date(e.t).toLocaleTimeString()} — {e.msg}{" "}
                {e.sig ? (
                  <a
                    href={explorerTx(e.sig)}
                    target="_blank"
                    rel="noreferrer"
                    style={{ textDecoration: "underline" }}
                  >
                    {shortSig(e.sig)}
                  </a>
                ) : null}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ✅ On-chain dashboard (live via websocket + refreshNonce fallback) */}
      <UserDashboard refreshNonce={dashboardRefreshNonce} />

      {receipt && (
        <div style={{ marginTop: 16 }}>
          <h2 style={{ fontSize: 18, fontWeight: 600 }}>Receipt</h2>
          <pre
            style={{
              marginTop: 8,
              padding: 12,
              background: "#111",
              color: "#0f0",
              borderRadius: 10,
              overflowX: "auto",
            }}
          >
            {JSON.stringify(receipt, null, 2)}
          </pre>
        </div>
      )}
    </main>
  );
}
